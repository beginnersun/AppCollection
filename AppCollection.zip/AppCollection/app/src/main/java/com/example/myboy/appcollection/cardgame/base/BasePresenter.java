package com.example.myboy.appcollection.cardgame.base;

public interface BasePresenter {
}
