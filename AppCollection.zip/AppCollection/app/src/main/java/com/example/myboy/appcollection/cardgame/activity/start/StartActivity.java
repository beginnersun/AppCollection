package com.example.myboy.appcollection.cardgame.activity.start;

public class StartActivity {
}
