package com.example.myboy.appcollection;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.myboy.appcollection.desktop.DeskTopActivity;
import com.example.myboy.appcollection.search.SortActivity;
import com.example.myboy.appcollection.search.bean.BaseBean;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    /**
     *
     * @param menu
     * @return false 不显示  true显示
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent();
        switch (item.getItemId()){
            case R.id.item_cardDemo:
                break;
            case R.id.item_jniDemo:
                break;
            case R.id.item_MapDemo:
                break;
            case R.id.item_mediaPlayerDemo:
                break;
            case R.id.item_videoPlayerDemo:
                break;
            case R.id.item_pictureDemo:
                break;
            case R.id.item_netWorkDemo:
                break;
            case R.id.item_socketDemo:
                break;
            case R.id.item_sortAlgorithm:
                intent.setClass(this,SortActivity.class);
                break;
            case R.id.item_searchAlgorithm:
                break;
            case R.id.item_desktop:
                intent.setClass(this,DeskTopActivity.class);
                break;
        }
        startActivity(intent);
        finish();
        return super.onOptionsItemSelected(item);
    }
}
