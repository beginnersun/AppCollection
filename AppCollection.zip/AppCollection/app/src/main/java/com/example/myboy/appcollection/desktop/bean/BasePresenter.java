package com.example.myboy.appcollection.desktop.bean;

public interface BasePresenter {
}
