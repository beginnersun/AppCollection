package com.example.myboy.appcollection.cardgame.activity.userinfo;

public class UserInfoActivity {
}
