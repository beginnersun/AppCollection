package com.example.myboy.appcollection.search.bean;

import java.io.File;

public class SortBean {

}
