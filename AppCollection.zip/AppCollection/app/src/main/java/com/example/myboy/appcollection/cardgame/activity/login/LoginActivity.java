package com.example.myboy.appcollection.cardgame.activity.login;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.example.myboy.appcollection.R;
import com.example.myboy.appcollection.cardgame.base.BaseActivity;
import com.example.myboy.appcollection.cardgame.base.BasePresenter;

public class LoginActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void setPresenter(BasePresenter basePresenter) {

    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_login;
    }

    @Override
    protected void queryInfo() {

    }

}
