package com.example.myboy.appcollection.cardgame.base;

public abstract class BaseBean {
}
