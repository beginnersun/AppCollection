package com.example.myboy.appcollection.cardgame.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity {

    BasePresenter basePresenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutResourceId());
        queryInfo();
    }

    protected abstract void setPresenter(BasePresenter basePresenter);

    /**
     * 获取layout资源id
     * @return
     */
    protected abstract int getLayoutResourceId();

    /**
     * 请求信息
     */
    protected abstract void queryInfo();

    /**
     * 刷新屏幕，重新请求信息
     */
    protected void refresh(){
        queryInfo();
    }

}
