package com.example.myboy.appcollection.cardgame.constant;

public class Constant {

    public static String host = "";

}
